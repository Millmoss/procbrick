﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class MetalNoise : MonoBehaviour
{
	public Material metalMat;
	public GameObject metalMesh;
	public int xSize;
	public int ySize;
	public Color metalColorA;
	public Color metalColorB;
	public int perlinOffset;
	public float xSplotching = 0.006f;
	public float ySplotching = 0.006f;
	public float xSpotting = .015f;
	public float ySpotting = .015f;
	public float spotCutoff = 0.15f;
	public float xBlotching = 0.01f;
	public float yBlotching = 0.006f;
	public float rustCutoff = .2f;

	private float[,] spots;

	void Start()
	{
		metalMesh.GetComponent<MeshRenderer>().material = metalMat;
		spots = new float[xSize, ySize];

		Texture2D metalTexture = new Texture2D(xSize, ySize, TextureFormat.ARGB32, false);
		Texture2D metalNormals = new Texture2D(xSize, ySize, TextureFormat.ARGB32, false);

		for (int y = 0; y < ySize; y++)
		{
			for (int x = 0; x < xSize; x++)
			{
				float zSplotch = (Mathf.Clamp(Mathf.PerlinNoise(x * xSplotching + perlinOffset, y * ySplotching + perlinOffset), 0.3f, 1f) + 3f) / 4f;
				float zSpot = Mathf.PerlinNoise(x * xSpotting - perlinOffset, y * ySpotting - perlinOffset);
				float zBlotch = (Mathf.Clamp(Mathf.PerlinNoise(x * xBlotching - perlinOffset, y * yBlotching - perlinOffset), 0.3f, 1f) + 3f) / 4f;
				if (zSpot <= spotCutoff)
					zSpot *= 1f / spotCutoff;
				else
					zSpot = 1;
				spots[x, y] = zSpot;
				Color c = metalColorA * Mathf.Clamp(zSplotch * zBlotch * zSpot, .7f, 1);
				if (zSplotch * zBlotch * zSpot < rustCutoff)
				{
					c = metalColorA * zSplotch * zBlotch * zSpot;
					c += metalColorB * (1 - zSplotch * zBlotch * zSpot);
				}
				metalTexture.SetPixel(x, y, c + new Color(0, 0, 0, 255));
			}
		}
		metalTexture.Apply();

		for (int y = 0; y < ySize; y++)
		{
			for (int x = 0; x < xSize; x++)
			{
				if (x == 0 || y == 0 || y == ySize - 1 || x == xSize - 1 || spots[x, y] >= 0.9f)
				{
					metalNormals.SetPixel(x, y, new Color(.5f, .5f, 1));
					continue;
				}
				float xDif = spots[x + 1, y] - spots[x, y] + spots[x, y] - spots[x - 1, y];
				xDif = xDif / 2 + spots[x, y] / 2;
				float yDif = spots[x, y + 1] - spots[x, y] + spots[x, y] - spots[x, y - 1];
				yDif = yDif / 2 + (1 - spots[x, y]) / 2;
				Vector3 dir = new Vector3(-xDif, -(xDif + yDif) / 2, -yDif);
				dir += Vector3.one;
				dir /= 2;
				metalNormals.SetPixel(x, y, new Color(dir.x, dir.y, dir.z));
			}
		}
		metalNormals.Apply();

		metalMat.SetTexture("_MainTex", metalTexture);
		metalMat.SetTexture("_BumpMap", metalNormals);

		byte[] bytes = ImageConversion.EncodeToPNG(metalTexture);
		FileStream file = File.Open(Application.dataPath + "/metl.png", FileMode.Create);
		BinaryWriter binary = new BinaryWriter(file);
		binary.Write(bytes);
		file.Close();
	}

	void Update()
    {
        
    }
}
